#ifndef GENERATE_RANDOM_H
#define GENERATE_RANDOM_H
#include"Input_Data.h"
//#include"ldlt.h"
//#include"lu_solver.h"
#include<fstream>
#include<random>
#include<fftw3.h> 

#define PI acos(-1)

//计算参考解
template<typename MatrixType1_, typename MatrixType2_, typename VectorType_>
inline void calculate_d_ref(MatrixType1_& d_ref, const MatrixType2_& mass, const MatrixType2_& stiff, const VectorType_& F, const VectorType_& d0, const VectorType_& dt0, int row, int Nt, fp64 dt)
{
	VectorType_ d1(row);
	fp64 cons = 0.5 * dt;
	d_ref.col(0) = d0.template cast<fp64>();
	MatrixType2_ MK, inv_MK, MK1, inv_MK1;
	MK = mass + cons * stiff;
	MK1 = mass - cons * stiff;
	inv_MK = MK.inverse();

	for (int i = 1; i < Nt + 1; ++i)
	{
		VectorTyped veci1 = MK1 * d_ref.col(i - 1);
		d_ref.col(i) = MK.lu().solve(veci1);
	}
}


template<typename MatrixType_, typename VectorType1_, typename VectorType2_, typename MatrixCType_>
inline void calculate_B_n(MatrixCType_ S1, const MatrixType_& mass, const MatrixType_& stiff, const VectorType2_& vecb, VectorType1_& D_t, VectorType1_& Da, int row, fp64 dt, int Nt, fp64 alp, double& theta) 
{
	VectorType1_ res(row * Nt); //定义残差向量
	VectorType1_ bk(row * Nt); 
	fp64 cons = 0.5 * dt;
	for (int i = 0; i < Nt; ++i) //计算\mathcal{K}*d
	{
		if (i == 0)
		{
			bk.segment(i * row, row) = (mass.template cast<fp64>() + cons * stiff.template cast<fp64>()) * D_t.segment(i * row, row);
		}
		else
		{
			bk.segment(i * row, row) = (-mass.template cast<fp64>() + cons * stiff.template cast<fp64>()) * (D_t.segment((i - 1) * row, row)) + (mass.template cast<fp64>() + cons * stiff.template cast<fp64>()) * D_t.segment(i * row, row);
		}
	}
	
	res = vecb.template cast<fp64>() - bk;
	theta = res.maxCoeff();
	res = res / theta;
	for (int i = 0; i < row; ++i)
	{
		fftw_complex* in_t = new fftw_complex[Nt];
		fftw_complex* out_t = new fftw_complex[Nt];

		fftw_plan P;
		P = fftw_plan_dft_1d(Nt, in_t, out_t, FFTW_FORWARD, FFTW_ESTIMATE);
		for (int j = 0; j < Nt; ++j)
		{
			in_t[j][0] = Da(j) * res(j * row + i);
			in_t[j][1] = 0;
		}

		fftw_execute(P);

		for (int j = 0; j < Nt; ++j)
		{
			S1[j][i] = thrust::complex<fp64>(fp64(out_t[j][0]), fp64(out_t[j][1])); 
		}

		fftw_destroy_plan(P);
		delete in_t;
		delete out_t;
	}

}

template<typename MatrixType_, typename VectorType_>
inline void calculate_b_k(VectorType_& b_k, const MatrixType_& stiff, const MatrixType_& mass, const VectorType_& F, const VectorType_& d0, const VectorType_& dt0, fp64 dt, int row, int Nt)
{
	VectorType_ d1(row);
	fp64 cons = 0.5 * dt;
	if (Nt == 1)
	{
		b_k.segment(0, row) = F * dt + mass * d0 - cons * stiff * d0;
	}
	else
	{
		b_k.segment(0, row) = F * dt + mass * d0 - (cons * stiff) * d0;

		for (int i = 2; i < Nt; ++i)
		{
			b_k.segment(i * row, row) = F * dt;
		}
	}

}

template<typename VectorCType_, typename VectorType_>
inline void update_D_t(const VectorCType_ D_b, VectorType_& D_t, int Nt, int row, fp64 alp, const double& theta)
{
	//先做逆傅里叶变换
	for (int i = 0; i < row; ++i)
	{
		fftw_complex* in_t = new fftw_complex[Nt];
		fftw_complex* out_t = new fftw_complex[Nt];

		fftw_plan P;
		P = fftw_plan_dft_1d(Nt, in_t, out_t, FFTW_BACKWARD, FFTW_ESTIMATE);
		for (int j = 0; j < Nt; ++j)
		{
			in_t[j][0] = D_b[j * row + i].real();
			in_t[j][1] = D_b[j * row + i].imag();
		}

		fftw_execute(P);

		for (int j = 0; j < Nt; ++j)
		{
			fp64 index1 = -j / (fp64)Nt;
			D_t(j * row + i) = D_t(j * row + i) + theta * pow(alp, index1) * out_t[j][0] / (fp64)Nt;
		}
		//std::cout << std::endl;

		fftw_destroy_plan(P);
		delete in_t;
		delete out_t;

	}
}

template<typename VectorType_>
void export_solution(std::string filename, VectorType_ D_t, int row, int Nt)
{
	std::ofstream file;
	file.open(filename.c_str());
	if (!file.is_open())
		std::cout << "File is not open, please check! " << std::endl;
	for (int i = 0; i < row * Nt; ++i)
	{
		file << D_t(i) << std::endl;
	}
	file.close();
}


#endif // !GENERATE_RANDOM_H

