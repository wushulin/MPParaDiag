#ifndef INPUT_DATA_H
#define INPUT_DATA_H
#include<iostream>
#include<string>
#include<sstream>
#include<fstream>
#include<vector>
#include<map>
#include<cuda_fp16.h>
#include"Eigen/Dense"
#include"Eigen/Core"
#include <thrust/complex.h>
//#include"ldlt.h"

#define CHUNKSIZE 4
#define FILE_K "./Input/Stiff.txt"
#define FILE_M "./Input/Mass.txt"
#define FILE_A_B "./Input/a_b.txt"
#define FILE_R "./Export/X_t.txt"
#define FILE_D "./Input/d0.txt"
#define FILE_DT "./Input/dt0.txt"
#define FILE_F "./Input/F.txt"
#define FILE_D_REF "./Export/d_ref.txt"

typedef Eigen::MatrixXd MatrixTyped;
typedef Eigen::VectorXd VectorTyped; 
typedef thrust::complex<double> MatrixCTyped;
typedef Eigen::VectorXcd VectorCTyped;
typedef Eigen::MatrixXf MatrixTypef;
typedef Eigen::VectorXf VectorTypef; 
typedef Eigen::MatrixXcf MatrixCTypef;
typedef Eigen::VectorXcf VectorCTypef; 
typedef Eigen::Matrix<Eigen::half, Eigen::Dynamic, Eigen::Dynamic> HalfMatrix;
typedef Eigen::Vector<Eigen::half, Eigen::Dynamic> HalfVector;

using fp16 = half; //half-precision
using fp32 = float; // single-precision
using fp64 = double; //double-precision

template<typename MatrixType_, typename VectorType_, typename VectorCType_>
class Input_Data
{
public:
	typedef Eigen::ComplexEigenSolver<MatrixType_> ces;
	//Input_Data();
	void read_matrix(std::string filename, MatrixType_& Matrix, int row, int col, double* h_matrix);
	void read_vector(std::string filename, VectorType_& vec, int row);
	void read_coefficient_A_B(std::string filename, VectorCType_ A, VectorCType_ B, int row);
};

template<typename MatrixType_, typename VectorType_, typename VectorCtype_>  // Eigen::MatrixXd or Eigen::MatrixXf
void  Input_Data<MatrixType_, VectorType_, VectorCtype_>::read_matrix(std::string filename, MatrixType_& Matrix, int row, int col, double* h_matrix)
{
	std::ifstream infile;
	infile.open(filename.c_str());
	if (infile.is_open())
	{
		for (int i = 0; i < row; ++i)
		{
			for (int j = 0; j < col; ++j)
			{
				fp64 temp;
				infile >> temp; 
				Matrix(i, j) = temp;
				h_matrix[i * row + j] = temp;
			}
		}
		infile.close();
	}
	else
	{
		std::cerr << "Unable to open file " << filename << std::endl;
	}
	infile.close();
	std::cout << "Read matrix data successfully " << std::endl;
}

template<typename MatrixType_, typename VectorType_, typename VectorCType_>  // Eigen::VectorXd or Eigen::VectorXf
void Input_Data<MatrixType_, VectorType_, VectorCType_>::read_vector(std::string filename, VectorType_& vec, int row)
{
	std::ifstream infile;
	infile.open(filename.c_str());
	if (infile.is_open())
	{
		for (int i = 0; i < row; ++i)
		{
			fp64 temp;
			infile >> temp; 
			vec(i) = temp;
		}
		infile.close();
		std::cout << "Read vector data successfully " << std::endl;
	}
	else
	{
		std::cerr << "Unable to open file " << filename << std::endl;
	}
}

template<typename MatrixType_, typename VectorType_, typename VectorCType_> //double or float
void Input_Data<MatrixType_, VectorType_, VectorCType_>::read_coefficient_A_B(std::string filename, VectorCType_ A, VectorCType_ B, int row)
{
	std::ifstream infile;
	infile.open(filename.c_str());
	if (infile.is_open())
	{
		for (int i = 0; i < row; ++i)
		{
			fp64 a_r, a_i, b_r, b_i;
			infile >> a_r >> a_i >> b_r >> b_i; 
			A[i].real(a_r), A[i].imag(a_i);
			B[i].real(b_r), B[i].imag(b_i);
		}
		infile.close();
		std::cout << "Read vector data successfully " << std::endl;
	}
	else
	{
		std::cerr << "Unable to open file " << filename << std::endl;
	}
}

#endif // !INPUT_DATA_H
