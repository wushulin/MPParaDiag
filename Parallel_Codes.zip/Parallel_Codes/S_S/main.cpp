//#define EIGEN_USE_MKL_ALL
//#define EIGEN_VECTORIZE_SSE4_2
#define EIGEN_USE_BLAS
#include <cstdlib>
#include "Input_Data.h"
#include "Generate_Random.h"
#include "lu_gpu.cuh"
#include<chrono>
#include<cmath>
//#include<mkl.h>

int main(int argc, char* argv[])
{
	system("mkdir Export");
	
	int row = 10588, col = 10588, Nt_tol, Nt, tmax = 10; 
	
	
	fp32 dt = 0.0125; //时间步
	fp32 tol = 1e-4; //迭代误差限
	fp32 alpha = 1e-3; // a parameter used in the ParaDiag algorithm
	bool flag = true; 

	Nt = 4;
	Nt_tol = Nt + 1;

	MPI_Init(&argc, &argv);
	int mrank, nprocs;
	MPI_Comm_rank(MPI_COMM_WORLD, &mrank);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

	Input_Data<MatrixTyped, VectorTypef, MatrixCTypef*> Input; //声明Input类
	MatrixTyped stiff, mass; // M, K
	fp64 *h_mass;
	fp64 *h_stiff; 
	MatrixCTypef** B_n = new MatrixCTypef*[Nt]; 
	VectorTypef d0(row), dt0(row); 
	MatrixCTypef *A, *B;
	VectorTypef F = VectorTypef::Zero(row); 
	VectorTypef b_k = VectorTypef::Zero(row * Nt); 
	stiff.resize(row, col);
	mass.resize(row, col);
	h_mass = (fp64 *)malloc(sizeof(fp64) * row * col);
	h_stiff = (fp64 *)malloc(sizeof(fp64) * row * col);
	A = (MatrixCTypef*)malloc(sizeof(thrust::complex<fp32>) * Nt);
	B = (MatrixCTypef*)malloc(sizeof(thrust::complex<fp32>) * Nt);
	MatrixTypef d_ref(row, Nt_tol); // 参考解，
	VectorTypef D_t = VectorTypef::Zero(row * Nt); // 当前时间步的解向量，实数
	MatrixCTypef* D_b = new MatrixCTypef[Nt * row];
	for(int i = 0; i < Nt; ++i)
	{
		B_n[i] = new thrust::complex<fp32>[row];
	}

	VectorTypef Err = VectorTypef::Zero(tmax + 1);
	
	if(mrank == 0)
	{
		//读取数据
		std::cout << "(-_-)---------------------------Pre-processing data part---------------------------(-_-)" << std::endl;
		auto begin_T = std::chrono::high_resolution_clock::now();
		Input.read_matrix(FILE_K, stiff, row, col, h_stiff);
		Input.read_matrix(FILE_M, mass, row, col, h_mass);
		Input.read_vector(FILE_D, d0, row);
		Input.read_vector(FILE_DT, dt0, row);
		Input.read_vector(FILE_F, F, row);
		
		calculate_b_k(b_k, stiff, mass, F, d0, dt0, dt, row, Nt); 

		auto end_T = std::chrono::high_resolution_clock::now();
		uint64_t cost_T = std::chrono::duration_cast<std::chrono::milliseconds>(end_T - begin_T).count();
		std::cout << "Read data successfully (^_^), and the time is " << cost_T << " ms. " << std::endl;
		std::cout << std::endl;

		//计算参考解
		auto begin_ts = std::chrono::high_resolution_clock::now();
		calculate_d_ref(d_ref, mass, stiff, F, d0, dt0, row, Nt, dt);
		d_ref.resize(row * Nt_tol, 1);
		auto end_ts = std::chrono::high_resolution_clock::now();
		std::cout << "(^_^)---------------------------Classical computing part---------------------------(^_^)" << std::endl;
		auto cost_ts = std::chrono::duration_cast<std::chrono::milliseconds>(end_ts - begin_ts).count();
		std::cout << "(^_^) Solve reference linear equations successfully (^_^), and the time is " << cost_ts << "ms. " << std::endl;
		std::cout << std::endl;
		export_solution(FILE_D_REF, d_ref, row, Nt_tol);
		Err(0) = (D_t.segment((Nt - 1) * row, row) - d_ref.col(0).segment((Nt_tol - 1) * row, row)).lpNorm<Eigen::Infinity>();
		printf("The initial ParaDiag_Error at is % 2.15f\n", Err(0));
		MPI_Bcast(stiff.data(), col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(mass.data(), col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(b_k.data(), row * Nt, MPI_FLOAT, 0, MPI_COMM_WORLD);
		MPI_Bcast(h_stiff, col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(h_mass, col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	}
	else 
	{
		MPI_Bcast(stiff.data(), col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(mass.data(), col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(b_k.data(), row * Nt, MPI_FLOAT, 0, MPI_COMM_WORLD);
		MPI_Bcast(h_stiff, col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(h_mass, col * row, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	}

	Input.read_coefficient_A_B(FILE_A_B, A, B, Nt);
	VectorTypef Da(Nt);
	for (int i = 0; i < Nt; ++i)
	{
		fp32 index1 = i / (fp32)Nt;
		Da(i) = pow(alpha, index1);
	}
	
	auto begin_P = std::chrono::high_resolution_clock::now();
	for(int t = 0; t < tmax; ++t)
	{
		if (!flag) break;
		
		calculate_B_n(B_n, mass, stiff, b_k, D_t, Da, row, dt, Nt, alpha);

		std::cout << "(-_-)---------------------------" << t << "'s  Parallel computing part-------------------------- - (-_-)" << std::endl;

		auto begin_t = std::chrono::high_resolution_clock::now();

		//计算step-b的解
		calculate_step_b_gpu(MPI_COMM_WORLD, h_mass, h_stiff, B_n, A, B, 1.0f, D_b, row, Nt, dt);
		
		auto end_t = std::chrono::high_resolution_clock::now();
		std::cout << "(^_^)---------------------------Parallel computing part---------------------------(^_^)" << std::endl;
		auto cost = std::chrono::duration_cast<std::chrono::milliseconds>(end_t - begin_t).count();
		std::cout << "(^_^) Solve complex linear equations successfully (^_^), and the time is " << cost << "ms. " << std::endl;
		std::cout << std::endl;

		if (mrank == 0)
		{
			//更新D_t
			update_D_t(D_b, D_t, Nt, row, alpha);
			Err(t + 1) = (D_t.segment((Nt - 1) * row, row) - d_ref.col(0).segment((Nt_tol - 1) * row, row)).lpNorm<Eigen::Infinity>();
			printf("ParaDiag_Error at % d - th iteration is % 2.15f\n", t + 1, Err(t + 1));
			if (Err(t + 1) < tol) flag = false;
		}
		
		
	}
	auto end_P = std::chrono::high_resolution_clock::now();
	auto cost_P = std::chrono::duration_cast<std::chrono::milliseconds>(end_P - begin_P).count();
	std::cout << " The total ParaDiag iteration process took " << cost_P << " ms. " << std::endl;


	if(mrank == 0)
	{
		std::cout << "(-_-)---------------------------Result output part---------------------------(-_-)" << std::endl;
		auto begin_ot = std::chrono::high_resolution_clock::now();
		export_solution(FILE_R, D_t, row, Nt);
		auto end_ot = std::chrono::high_resolution_clock::now();
		auto cost_ot = std::chrono::duration_cast<std::chrono::milliseconds>(end_ot - begin_ot).count();
		std::cout << "(^_^) The output file was successfully written (^_^), and the time is " << cost_ot << " ms. " << std::endl;
	}
	MPI_Finalize();

	return 0;
}

