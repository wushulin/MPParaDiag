clc;
clear;
global alp Kmax Nt T Nx nu dt
nu=1e-3;
alp=1e-7;
Kmax=7;
dx=1/40;
x=-1:dx:1;
Nx=length(x);
Err1=zeros(1,Kmax); % store globel error for Standard Mode
Err2=zeros(1,Kmax); % store globel error for New Mode
T=2;
dt=1/50;
t=0:dt:T;
Nt=T/dt;
B=toeplitz([0;1;zeros(Nt-2,1)],[0,zeros(1,Nt-1)]);
C=B;
e=ones(Nx,1);
A1=nu*spdiags([-e,2*e,-e]/dx^2,[-1,0,1],Nx,Nx);
A2=spdiags([-e,0*e,e]/(2*dx),[-1,0,1],Nx,Nx);
A=nu*A1+A2;
Ix=eye(Nx);
r1=Ix+0.5*dt*A;
r2=-Ix+0.5*dt*A;

U0=zeros(Nx,1); 
for j=1:Nx 
    U0(j,1)=x(j)^2*cos(2*pi*x(j));
end
Ix=speye(Nx);
b0=zeros(Nx*Nt,1);
b0(1:Nx)=-r2*U0;
U_sint=zeros(Nx,Nt+1);
U_sint(:,1)=U0;
invA=-r1\r2;
for n=1:Nt
    U_sint(:,n+1)=invA*U_sint(:,n);
end
Uk0=random('unif',-1,1,Nx*Nt,1);
C(1,Nt)=alp;
c=zeros(Nt,1);c(1:3)=C(1:3,1)';
Da=alp.^((0:Nt-1)'/Nt);
invDa=alp.^((0:-1:1-Nt)'/(Nt));
D=fft(Da.*c);   
CondK=zeros(1,Nt);
for n=1:Nt
    Kn=r1+D(n)*r2;
    CondK(n)=condest(eye(Nx)/Kn,2);
end
%%%------ Direct Mode-------
Uk=Uk0;
k=1;
Err1(k)=norm(Uk-reshape(U_sint(:,2:Nt+1),Nt*Nx,1),inf);
fprintf('Direct Error at %d-th iteration is %2.15f\n',k,Err1(k));
bk=zeros(Nx*Nt,1);
for k=2:Kmax
   bk(1:Nx)=alp*r2*Uk((Nt-1)*Nx+1:Nt*Nx);
   res=reshape(bk+b0,Nx,Nt);
   S1=fft(Da.*(res.')).';
   S2=zeros(Nx,Nt);
    for n=1:Nt 
       S2(:,n)=(r1+r2*D(n))\S1(:,n);
    end 
    Uk=reshape((invDa.*ifft(S2.')).',Nx*Nt,1); 
    if k==2
       IRUk=Uk;
    end
    Err1(k)=norm(Uk-reshape(U_sint(:,2:Nt+1),Nt*Nx,1),inf);
    fprintf('Direct_Error at %d-th iteration is %2.15f\n', k,Err1(k));
end
 
%%%------ IR Mode------- 
Uk=Uk0;
k=1;
Err2(k)=norm(Uk-reshape(U_sint(:,2:Nt+1),Nt*Nx,1),inf);
fprintf('IR_Error at %d-th iteration is %2.15f\n',k,Err2(k));


Uk=IRUk;
k=2;
Err2(k)=norm(Uk-reshape(U_sint(:,2:Nt+1),Nt*Nx,1),inf);
fprintf('IR_Error at %d-th iteration is %2.15f\n',k,Err2(k));


Da=single(alp.^((0:Nt-1)'/Nt));
invDa=single(alp.^((0:-1:1-Nt)'/(Nt)));
D=single(fft(single(Da.*c)));  
S2=single(zeros(Nx,Nt));
bk=zeros(Nx*Nt,1);
for k=3:Kmax
    for n=1:Nt
        if n==1
            bk((n-1)*Nx+1:n*Nx)=r1*Uk((n-1)*Nx+1:n*Nx);
        else
            bk((n-1)*Nx+1:n*Nx)=r1*Uk((n-1)*Nx+1:n*Nx)+r2*Uk((n-2)*Nx+1:(n-1)*Nx);
        end
    end
   res=single(reshape(b0-bk,Nx,Nt)); 
   S1=single(fft(Da.*(res.'))).';
    for n=1:Nt 
        S2(:,n)=single(single(r1+r2*D(n))\S1(:,n));
    end 
    Uk=Uk+double(reshape((invDa.*single(ifft(S2.'))).',Nx*Nt,1)); 
    Err2(k)=norm(Uk-reshape(U_sint(:,2:Nt+1),Nt*Nx,1),inf);
    fprintf('IR_Error at %d-th iteration is %2.15f\n',k,Err2(k));
end
 

% figure(1);
% Kmax1=10;
% semilogy(0:Kmax1-1,Err1(1,1:Kmax1),'r-o',0:Kmax1-1,Err2(1:Kmax1),'b-+','markersize',11,'linewidth',1);shg
% set(gca,'fontsize',14);
% xlabel('Iteration Index','fontsize',20);
% ylabel('Measured Error','fontsize',20);
% xlim([0,Kmax1-1]);
% ylim([1e-16,4.4]);
% set(gca,'xtick',0:Kmax1-1);
% set(gca,'ytick',10.^(-16:2:0));
% leg=legend('Direct ($\alpha=1e-11$)','Direct ($\alpha=1e-6$)','Direct ($\alpha=1e-3$)',...
%     'IR  ($\alpha=1e-11$)','IR  ($\alpha=1e-6$)','IR ($\alpha=1e-3$)');
% set(leg,'fontsize',15,'interpreter','latex');

% Err2=[   2.485216083580763
%    0.000002482708592
%    0.000000002518529
%    0.000000000000109
%    0.000000000000017
%    0.000000000000019
%    0.000000000000018];
Err2=[2.286879250924315
   0.000000309334161
   0.000000011020433
   0.000000000000038
   0.000000000000017
   0.000000000000019
   0.000000000000017];
figure(1);
semilogy(0:Kmax-1,Err1(1:Kmax),'r-o',0:Kmax-1,Err2(1:Kmax),'b-s','linewidth',1,'markersize',11);shg
hold on;
semilogy(0:Kmax-1,((eps/alp))*ones(Kmax),'k-.',0:Kmax-1,(eps*2*max(CondK))*ones(Kmax),'k-.','linewidth',0.5);shg
hold off;
set(gca,'fontsize',14);shg
xlim([0,Kmax-1]);
ylim([1e-16,4]);
set(gca,'ytick',10.^(-16:1:0));
set(gca,'xtick',0:Kmax-1);
xlabel('Iteration Number: $k$','interpreter','latex','fontsize',19);
ylabel('Error','interpreter','latex','fontsize',22);
title(['$\alpha$=',num2str(alp)],'fontsize',22,'interpreter','latex');
leg=legend('Direct','Hybrid $(\mathbf{y}^1_{\rm direct}, \mathbf{y}^{2,3,...}_{\rm IR})$');
% leg=legend('Direct','IR-Based');
set(leg,'fontsize',18,'interpreter','latex');
box off     % ȡ���߿�

