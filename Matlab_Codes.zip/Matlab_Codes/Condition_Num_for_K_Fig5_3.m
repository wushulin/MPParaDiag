 clc;
clear;
global Nt T Nx nu dt alp
nu=1e-2
alp=1e-8;
dx=1/100;
x=-1:dx:1;
Nx=length(x);
T=10;
dt=1/32;
Nt=T/dt;
B=toeplitz([0;1;zeros(Nt-2,1)],[0,zeros(1,Nt-1)]);
C=B;
e=ones(Nx,1);
A1=nu*spdiags([-e,2*e,-e]/dx^2,[-1,0,1],Nx,Nx);

A2=spdiags([-e,0*e,e]/(2*dx),[-1,0,1],Nx,Nx);
A1(1,Nx)=A1(2,1);
A1(Nx,1)=A1(1,2);
A2(1,Nx)=A2(2,1);
A2(Nx,1)=A2(1,2);
A=1*A1+A2;
eigA=eig(full(A));
CondK=zeros(1,Nx);
It=eye(Nt);
Ix=eye(Nx);
r1=Ix+0.5*dt*A;
r2=-Ix+0.5*dt*A;
C(1,Nt)=alp;
c=zeros(Nt,1);c(1:3)=C(1:3,1)';
Da=alp.^((0:Nt-1)'/Nt);
invDa=alp.^((0:-1:1-Nt)'/(Nt));
D=fft(Da.*c);   
CondK=zeros(1,Nt);
for n=1:Nt
    K=r1+D(n)*r2;
    CondK(n)=condest(eye(Nx)/K,2);
end
% for j=1:Nx
%     lam=eigA(j);
%     r1=1+0.5*dt*lam;
%     r2=-1+0.5*dt*lam;
%     K=It*r1+B*r2;
%     CondK(j)=condest(K,2);
% end
% plot3(real(eigA),imag(eigA),CondK,'o','markersize',10);shg
%set(gca,'Zscale','log')
plot3(real(D),imag(D),CondK,'o','markersize',10);shg
title(['Cond=',num2str(max(CondK))],'fontsize',20);
 


% KK=kron(It,r1)+kron(B,r2);
% condest(KK,2)


% for j=1:Nx
%     lam=eigA(j);
%     r1=1+0.5*dt*lam;
%     r2=-1+0.5*dt*lam;
%     K=It*r1+B*r2;
%     CondK(j)=condest(K,2);
% end
% plot3(real(eigA),imag(eigA),CondK,'o','markersize',10);shg
% %set(gca,'Zscale','log')
% title(['Cond=',num2str(max(CondK))],'fontsize',20);
% xlim([1,Nx])
