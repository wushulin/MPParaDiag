clc;
%clear;
global dt T dx theta alp nu Nx Nt flag_IR Kmax Tol
Kmax=7;
Tol=1e-15;
flag_IR=1;
 
alp=1e-7;
T=2;
dt=1/50;
Nt=T/dt; 
t=0:dt:T;
dx=1/64;
Nx=1/dx;
theta=1/2;
e=ones(Nx,1);
A1=spdiags([-e e], [-1,1], Nx, Nx)/(2*dx);
A2= spdiags([-e 2*e -e], -1:1, Nx, Nx)/(dx^2);
 
Ix=eye(Nx);
if nu<0
    A=A2;
else
    A=A1+nu*A2;
end
%------GMRES solver for K*U=b------
r1=Ix+dt*theta*A;
r2=-Ix+dt*(1-theta)*A;
inv_r1=Ix/r1;
b=zeros(Nx*Nt,1);
x=linspace(0,1,Nx)';
u0=sin(2*pi*x);
b(1:Nx)=-r2*u0;
U_ref=zeros(Nx,Nt+1);
U_ref(:,1)=u0;
for n=1:Nt
     U_ref(:,n+1)=inv_r1*(-r2*U_ref(:,n));
end
if flag_IR==1
    It_total=zeros(1,Kmax);
    Uk=kron(ones(Nt,1),0.125*u0);
    Error=zeros(1,Kmax);
    k=1;
    Error(k)=max(max(abs(U_ref(:,2:Nt+1)-reshape(Uk,Nx,Nt))));
    fprintf('Error at %d-th iteration is %2.15f\n',k,Error(k));
    for k=2:Kmax
        res=single(b-K_times_U(Uk,r1,r2));
        u_ini=single(zeros(Nx*Nt,1));
        [dU,FLAG,RELRES,ITER,RESVEC]=gmres(@(u)K_times_U(u,single(r1),single(r2)),res,[],Tol,120,...
            @(u)invP_times_U(u,single(r1),single(r2)),[],u_ini);
        It_total(k)=ITER(2);
        Uk=double(dU)+Uk;
        Error(k)=max(max(abs(U_ref(:,2:Nt+1)-reshape(Uk,Nx,Nt))));
        fprintf('Error at %d-th iteration is %2.15f\n',k,Error(k));
        if Error(k)<=Tol
            break;
        end
    end
else
    k=1; 
    u_ini=(zeros(Nx*Nt,1));
    Error(k)=max(max(abs(U_ref(:,2:Nt+1)-reshape(u_ini,Nx,Nt))));
    fprintf('Error at %d-th iteration is %2.15f\n',k,Error(k));
    for k=2:Kmax
        [X,FLAG,RELRES,ITER,RESVEC]=gmres(@(u)K_times_U(u,r1,r2),b,[],Tol,k-1,...
            @(u)invP_times_Ud(u,r1,r2),[],u_ini);
       Error(k)=max(max(abs(U_ref(:,2:Nt+1)-reshape(X,Nx,Nt))));
        fprintf('Error at %d-th iteration is %2.15f\n',k,Error(k));
        if Error(k)<=Tol
            break;
        end
    end
end
figure(1);
%if flag_IR==1
    if alp==1e-3
        semilogy(0:length(Error)-1,Error,'b-->','markersize',10);shg;
        hold on;
    else
        semilogy(0:length(Error)-1,Error,'b-.*','markersize',10);shg;
        hold off;
    end
%end
set(gca,'fontsize',14);
xlim([0,length(Error)-1]);
ylim([1e-15,max(Error)]);
%set(gca,'xtick',[0:length(Error)-1]);

set(gca,'ytick',10.^(-14:2:0));
xlabel('IR Iteration Index','interpreter','latex','fontsize',20);
ylabel('Global Error','interpreter','latex','fontsize',20);
if flag_IR==1
    title('$(\epsilon_d, \epsilon_s)$-precision','fontsize',20,'Interpreter','latex');
else 
    title('uniform double precison $\epsilon_d$','fontsize',20,'Interpreter','latex');
end
function val=K_times_U(u,r1,r2)
global Nt
Nx=length(r1(:,1));
U=reshape(u,Nx,Nt);
Z=zeros(Nx,Nt);
for n=1:Nt
    if n==1
        Z(:,n)=r1*U(:,n);
    else
        Z(:,n)=r1*U(:,n)+r2*U(:,n-1);
    end
end
val=reshape(Z,Nx*Nt,1);
end
function val=invP_times_U(u,r1,r2)
global Nt alp
Nx=length(r1(:,1));
U=reshape(u,Nx,Nt);
c=single(zeros(Nt,1));
c(2,1)=1;
Da=single(alp.^((0:Nt-1)'/Nt));
invDa=single(alp.^((0:-1:1-Nt)'/(Nt)));
D=single(fft(Da.*c));   
 
S1=single(fft(Da.*(U.')).');
S2=single(zeros(Nx,Nt));
for n=1:Nt 
        S2(:,n)=single((r1+r2*D(n))\S1(:,n));
end 
val=single(reshape((invDa.*ifft(S2.')).',Nx*Nt,1)); 
end

function val=invP_times_Ud(u,r1,r2)
global Nt alp
Nx=length(r1(:,1));
U=reshape(u,Nx,Nt);
c=(zeros(Nt,1));
c(2,1)=1;
Da=(alp.^((0:Nt-1)'/Nt));
invDa=(alp.^((0:-1:1-Nt)'/(Nt)));
D=(fft(Da.*c));   
 
S1=(fft(Da.*(U.')).');
S2=(zeros(Nx,Nt));
for n=1:Nt 
        S2(:,n)=((r1+r2*D(n))\S1(:,n));
end 
val=(reshape((invDa.*ifft(S2.')).',Nx*Nt,1)); 
end