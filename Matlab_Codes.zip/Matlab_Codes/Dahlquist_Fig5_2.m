clc;
clear;
global alp Kmax Nt T omg dt
omg=5;
alp=1e-3;
Kmax=5;
Err1=zeros(1,Kmax); % store globel error for direct implementation
Err2=zeros(1,Kmax); % store globel error for IR-based implementation
T=10;
dt=1/50;
t=0:dt:T;
Nt=T/dt;
It=eye(Nt);
B=toeplitz([0;1;zeros(Nt-2,1)],[0,zeros(1,Nt-1)]);
C=B;
r1=1+0.5*(1i*dt*omg)-(dt*omg)^2/12;
r2=1-0.5*(1i*dt*omg)-(dt*omg)^2/12;
K=r1*eye(Nt)+r2*B;
C(1,Nt)=C(2,1)*alp;
P=r1*eye(Nt)+r2*C;
c=zeros(Nt,1);c(1:3)=C(1:3,1)';
Da=alp.^((0:Nt-1)'/Nt);
invDa=alp.^((0:-1:1-Nt)'/(Nt));
D=fft(Da.*c);   
%%%------ 5-steps-------
err=zeros(Nt,Kmax);
err(:,1)=random('unif',-2,2,Nt,1);
for k=1:Kmax-1
    yi0=K*err(:,k);
    res=reshape(yi0,1,Nt);
    yi1=Da.*(res.');
    yi2=fft(yi1).';
    yi3=zeros(1,Nt);
    for n=1:Nt 
        yi3(n)=(r1+r2*D(n))\yi2(n);
    end 
    yi4=ifft(yi3.');
    err(:,k+1)=reshape((invDa.*yi4).',Nt,1);
end
k=1;
semilogy(1:Nt,abs(err(:,k+1)-err(:,k)),'b:o');shg



% xi0=K*e0;
% res=reshape(xi0,1,Nt); 
% xi1=(res.');
% xi2=fft(Da.*xi1).';
% xi3=zeros(1,Nt);
% for n=1:Nt 
%     xi3(n)=(r1+r2*D(n))\xi2(n);
% end 
% xi4=ifft(xi3.');
% xi5=reshape((invDa.*xi4).',Nt,1); 

% figure(2);
% semilogy(1:Nt,abs(xi0),'r-',...
%     1:Nt,abs(xi1),'b-',...
%     1:Nt,abs(xi2),'b-',...
%     1:Nt,abs(xi3),'b-',...
%     1:Nt,abs(xi4),'m-',...
%     1:Nt,abs(xi5),'c-',...
%     'linewidth',1,'markersize',11);shg
% set(gca,'fontsize',14);shg
% xlim([1,Nt]);
% %ylim([1e-16,4]);
% %set(gca,'ytick',10.^(-16:1:0));
% %set(gca,'xtick',0:Kmax-1);
% xlabel('Time Point Index: $n$','interpreter','latex','fontsize',19);
% %ylabel('Error','interpreter','latex','fontsize',22);
% title(['$\alpha$=',num2str(alp)],'fontsize',22,'interpreter','latex');
% %leg=legend('Direct','IR-based');
% %set(leg,'fontsize',18);
% box off     % ȡ���߿�
%  
