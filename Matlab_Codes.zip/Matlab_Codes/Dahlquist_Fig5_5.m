clc;
clear;
global alp Kmax Nt T omg dt
omg=5;
alp=1e-6;
Kmax=8;
Err1=zeros(1,Kmax); % store globel error for direct implementation
Err2=zeros(1,Kmax); % store globel error for IR-based implementation
T=10;
dt=1/50;
t=0:dt:T;
Nt=T/dt;
B=toeplitz([0;1;zeros(Nt-2,1)],[0,zeros(1,Nt-1)]);
C=B;
r1=1+0.5*(1i*dt*omg)-(dt*omg)^2/12;
r2=1-0.5*(1i*dt*omg)-(dt*omg)^2/12;
K=r1*eye(Nt)+r2*B;
y0=1; 
b0=zeros(Nt,1);
b0(1)=-r2*y0;
y_sint=zeros(Nt+1,1);
y_sint(1)=y0;
for n=1:Nt
    y_sint(n+1)=(-r1\r2)*y_sint(n);
end
yk0=random('unif',-1,1,Nt,1);
C(1,Nt)=alp;
c=zeros(Nt,1);c(1:3)=C(1:3,1)';
Da=alp.^((0:Nt-1)'/Nt);
invDa=alp.^((0:-1:1-Nt)'/(Nt));
D=fft(Da.*c);   
%%%------ Direct Mode-------
yk=yk0;
k=1;
Err1(k)=norm(yk-y_sint(2:Nt+1),inf);
fprintf('Direct Error at %d-th iteration is %2.15f\n',k,Err1(k));
bk=zeros(Nt,1);
for k=2:Kmax
   bk(1)=alp*r2*yk(Nt);
   res=reshape(bk+b0,1,Nt);
   S1=fft(Da.*(res.')).';
   S2=zeros(1,Nt);
    for n=1:Nt 
        S2(n)=(r1+r2*D(n))\S1(n);
    end 
    yk=reshape((invDa.*ifft(S2.')).',Nt,1); 
    if k==2
        yIR=yk;
    end
    Err1(k)=norm(yk-y_sint(2:Nt+1),inf);
    fprintf('Direct_Error at %d-th iteration is %2.15f\n', k,Err1(k));
end
yk00=yk;
%%%------ IR Mode------- 
yk=yk0;
k=1;
Err2(k)=norm(yk-y_sint(2:Nt+1),inf);
fprintf('IR_Error at %d-th iteration is %2.15f\n',k,Err2(k));
yk=yIR;
k=2;
Err2(k)=norm(yk-y_sint(2:Nt+1),inf);
fprintf('IR_Error at %d-th iteration is %2.15f\n',k,Err2(k));
bk=zeros(Nt,1);
for k=3:Kmax
    for n=1:Nt
        if n==1
            bk(n)=r1*yk(n);
        else
            bk(n)=r1*yk(n)+r2*yk(n-1);
        end
    end
   res=single(reshape(b0-bk,1,Nt)); 
   S1=single(fft(single(Da).*(res.'))).';
   S2=zeros(1,Nt);
    for n=1:Nt 
            S2(n)=single((single(r1)+single(r2)*single(D(n)))\S1(n));
    end 
    dyk=reshape((single(invDa).*single(ifft(S2.'))).',Nt,1);
    yk=yk+double(dyk); 
    Err2(k)=norm(yk-y_sint(2:Nt+1),inf);
    fprintf('IR_Error at %d-th iteration is %2.15f\n',k,Err2(k));
end
 


figure(1);
semilogy(0:Kmax-1,Err1(1:Kmax),'r-o',0:Kmax-1,Err2(1:Kmax),'b-s','linewidth',1,'markersize',11);shg
hold on;
semilogy(0:Kmax-1,((eps/alp))*ones(Kmax),'k-.',0:Kmax-1,(eps*cond(K,2))*ones(Kmax),'k-.','linewidth',0.5);shg
hold off;
set(gca,'fontsize',14);shg
xlim([0,Kmax-1]);
ylim([1e-16,4]);
set(gca,'ytick',10.^(-16:1:0));
set(gca,'xtick',0:Kmax-1);
xlabel('Iteration Number: $k$','interpreter','latex','fontsize',19);
ylabel('Error','interpreter','latex','fontsize',22);
title(['$\alpha$=',num2str(alp)],'fontsize',22,'interpreter','latex');
leg=legend('Direct','Hybrid $(\mathbf{y}^1_{\rm direct}, \mathbf{y}^{2,3,...}_{\rm IR})$');
set(leg,'fontsize',18,'interpreter','latex');
box off     % ȡ���߿�
 
